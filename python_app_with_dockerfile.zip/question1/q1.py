num1 = int(input("Enter first number : "))
num2 = int(input("Ender Second number :"))
add = num1 + num2
mul=num1 * num2
print("Addition of two numbers =",add)
print("Multiplication of two numbers=",mul)


