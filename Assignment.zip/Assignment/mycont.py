import mysql.connector
mydb = mysql.connector.connect(
		host = "mycont1",
		user="root",
		passwd="change",
		auth_plugin="mysql_native_password")
test_cursor=mydb.cursor()
test_cursor.execute("CREATE DATABASE assignment2db")
test_cursor.execute("SHOW DATABASES")
for x in test_cursor:
	print(x)
